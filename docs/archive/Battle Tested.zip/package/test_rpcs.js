// Test script to verify Supabase RPC functions work correctly
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://mthwfldcjvpxjtmrqkqm.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10aHdmbGRjanZweGp0bXJxa3FtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU3MjkxNjQsImV4cCI6MjA4MTMwNTE2NH0.0yANezx06a-NgPSdNjeuUG3nEng5y1BbWX9Bf6Oxlrg';

const supabase = createClient(supabaseUrl, supabaseKey);

async function testRPCs() {
  console.log('Testing Supabase RPC functions...\n');

  // Test 1: get_user_balance
  console.log('1. Testing get_user_balance...');
  try {
    const { data, error } = await supabase.rpc('get_user_balance', { 
      p_user_identifier: '0x1234567890123456789012345678901234567890' 
    });
    if (error) throw error;
    console.log('   ✓ get_user_balance works:', JSON.stringify(data));
  } catch (e) {
    console.log('   ✗ get_user_balance failed:', e.message);
  }

  // Test 2: get_unavailable_tickets
  console.log('\n2. Testing get_unavailable_tickets...');
  try {
    const { data, error } = await supabase.rpc('get_unavailable_tickets', { 
      p_competition_id: 'test-competition-id' 
    });
    if (error) throw error;
    console.log('   ✓ get_unavailable_tickets works:', JSON.stringify(data));
  } catch (e) {
    console.log('   ✗ get_unavailable_tickets failed:', e.message);
  }

  // Test 3: get_competition_entries
  console.log('\n3. Testing get_competition_entries...');
  try {
    const { data, error } = await supabase.rpc('get_competition_entries', { 
      p_competition_id: 'test-competition-id',
      p_limit: 10,
      p_offset: 0
    });
    if (error) throw error;
    console.log('   ✓ get_competition_entries works:', JSON.stringify(data));
  } catch (e) {
    console.log('   ✗ get_competition_entries failed:', e.message);
  }

  // Test 4: Query competitions table
  console.log('\n4. Testing direct table query (competitions)...');
  try {
    const { data, error } = await supabase.from('competitions').select('id, title, status').limit(5);
    if (error) throw error;
    console.log('   ✓ Competitions query works, found', data?.length || 0, 'records');
    if (data && data.length > 0) console.log('   Sample:', JSON.stringify(data[0]));
  } catch (e) {
    console.log('   ✗ Competitions query failed:', e.message);
  }

  // Test 5: Query canonical_users table
  console.log('\n5. Testing direct table query (canonical_users)...');
  try {
    const { data, error } = await supabase.from('canonical_users').select('id, canonical_user_id').limit(3);
    if (error) throw error;
    console.log('   ✓ canonical_users query works, found', data?.length || 0, 'records');
  } catch (e) {
    console.log('   ✗ canonical_users query failed:', e.message);
  }

  // Test 6: Query sub_account_balances table
  console.log('\n6. Testing direct table query (sub_account_balances)...');
  try {
    const { data, error } = await supabase.from('sub_account_balances').select('id, canonical_user_id, available_balance').limit(3);
    if (error) throw error;
    console.log('   ✓ sub_account_balances query works, found', data?.length || 0, 'records');
  } catch (e) {
    console.log('   ✗ sub_account_balances query failed:', e.message);
  }

  console.log('\n=== RPC Tests Complete ===');
}

testRPCs().catch(console.error);
