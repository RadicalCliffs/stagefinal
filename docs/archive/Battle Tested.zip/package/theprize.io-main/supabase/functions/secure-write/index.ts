import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

// Helper functions
function isWalletAddress(identifier: string): boolean {
  return /^0x[a-fA-F0-9]{40}$/.test(identifier);
}

function toPrizePid(inputUserId: string | null | undefined): string {
  if (!inputUserId || inputUserId.trim() === '') {
    return `prize:pid:${crypto.randomUUID()}`;
  }
  const trimmedId = inputUserId.trim();
  if (trimmedId.startsWith('prize:pid:')) {
    return trimmedId.toLowerCase();
  }
  if (isWalletAddress(trimmedId)) {
    return `prize:pid:${trimmedId.toLowerCase()}`;
  }
  return `prize:pid:${trimmedId.toLowerCase()}`;
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, PATCH, OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  if (req.method !== 'POST' && req.method !== 'PATCH') {
    return new Response(JSON.stringify({ error: 'Method not allowed', ok: false }), {
      status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const serviceClient = createClient(supabaseUrl, serviceRoleKey);

    // Simplified auth - just extract wallet address from Bearer token
    const authHeader = req.headers.get('Authorization');
    const token = authHeader?.replace('Bearer ', '').trim() || '';
    
    // Accept wallet address directly - no JWT verification
    let userId = '';
    let walletAddress = '';
    
    if (isWalletAddress(token)) {
      walletAddress = token.toLowerCase();
      userId = toPrizePid(token);
    } else {
      // Try to extract from body if not in header
      const tempBody = await req.clone().json().catch(() => ({}));
      if (tempBody.wallet_address && isWalletAddress(tempBody.wallet_address)) {
        walletAddress = tempBody.wallet_address.toLowerCase();
        userId = toPrizePid(tempBody.wallet_address);
      } else {
        return new Response(JSON.stringify({ error: 'Wallet address required', ok: false }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    const url = new URL(req.url);
    const pathParts = url.pathname.split('/').filter(Boolean);
    const route = pathParts.slice(1).join('/');
    const body = await req.json().catch(() => ({}));

    if (route === 'transactions/create') {
      const { competition_id, ticket_count, amount, reservation_id, payment_provider, network } = body;
      const finalWalletAddress = body.wallet_address || walletAddress;
      const isTopUp = !competition_id;

      if (!isTopUp && (!finalWalletAddress || !competition_id || !ticket_count || !amount)) {
        return new Response(JSON.stringify({ error: 'Missing required fields', ok: false }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      if (isTopUp && !amount) {
        return new Response(JSON.stringify({ error: 'Missing amount', ok: false }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const now = new Date().toISOString();
      const transactionData: Record<string, any> = {
        user_id: userId,
        user_privy_id: userId,
        wallet_address: finalWalletAddress,
        amount, currency: "USDC", network: network || "base",
        payment_provider: payment_provider || "privy_base_wallet",
        status: "pending", payment_status: "pending",
        type: isTopUp ? "topup" : "entry",
        created_at: now, updated_at: now,
      };

      if (!isTopUp) {
        transactionData.competition_id = competition_id;
        transactionData.ticket_count = ticket_count;
      } else {
        transactionData.competition_id = null;
        transactionData.ticket_count = 0;
      }

      const result = await serviceClient.from("user_transactions").insert(transactionData).select("id").single();

      if (result.error) {
        return new Response(JSON.stringify({ error: result.error.message, ok: false }), {
          status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      if (reservation_id && !isTopUp) {
        await serviceClient.from("pending_tickets").update({ session_id: result.data.id }).eq("id", reservation_id);
      }

      return new Response(JSON.stringify({ ok: true, transactionId: result.data.id, totalAmount: amount, isTopUp }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (route === 'balance/topup') {
      const { transaction_id, amount: topupAmount } = body;
      if (!transaction_id || !topupAmount) {
        return new Response(JSON.stringify({ error: 'Missing fields', ok: false }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const { data: txData } = await serviceClient
        .from("user_transactions").select("id, user_id, amount, status, wallet_credited").eq("id", transaction_id).single();

      if (!txData) {
        return new Response(JSON.stringify({ error: 'Transaction not found', ok: false }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      if (txData.wallet_credited) {
        return new Response(JSON.stringify({ ok: true, alreadyCredited: true }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const lookupCanonicalId = toPrizePid(txData.user_id);
      const { data: userData } = await serviceClient
        .from("canonical_users").select("id, usdc_balance").eq("canonical_user_id", lookupCanonicalId).maybeSingle();

      if (!userData) {
        return new Response(JSON.stringify({ error: 'User not found', ok: false }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      await serviceClient.from("balance_ledger").insert({
        user_id: userData.id, balance_type: "real", source: "topup", amount: topupAmount,
        transaction_id, metadata: { payment_provider: "privy_base_wallet" },
        created_at: new Date().toISOString(), expires_at: null,
      });

      const newBalance = Number(userData.usdc_balance || 0) + Number(topupAmount);
      await serviceClient.from("canonical_users").update({ usdc_balance: newBalance, updated_at: new Date().toISOString() }).eq("id", userData.id);
      await serviceClient.from("user_transactions").update({ wallet_credited: true, updated_at: new Date().toISOString() }).eq("id", transaction_id);

      return new Response(JSON.stringify({ ok: true, credited: topupAmount, newBalance }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ error: `Unknown route: ${route}`, ok: false }), {
      status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Internal error', ok: false }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
