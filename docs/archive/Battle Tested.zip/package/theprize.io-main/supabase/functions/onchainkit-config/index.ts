// OnchainKit Configuration Edge Function
// Returns the CDP API key and config for OnchainKit initialization

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Max-Age': '86400',
};

// CDP RPC API Key for OnchainKit - used in RPC URL construction
const CDP_RPC_API_KEY = "QEcbaTIUVqvhvAVEh7D0jKXm6hztpgZQ";
const CDP_PROJECT_ID = "71e24c24-c628-460c-82e3-f830a2b0daf1";

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    // Check for env override
    const apiKey = Deno.env.get('ONCHAINKIT_API_KEY') || CDP_RPC_API_KEY;
    const projectId = Deno.env.get('CDP_PROJECT_ID') || CDP_PROJECT_ID;
    const useMainnet = Deno.env.get('VITE_BASE_MAINNET') === 'true';

    return new Response(
      JSON.stringify({
        success: true,
        config: {
          apiKey,
          projectId,
          network: useMainnet ? 'base' : 'base-sepolia',
          chainId: useMainnet ? 8453 : 84532,
        },
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: { code: 'INTERNAL_ERROR', message: error.message } }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
