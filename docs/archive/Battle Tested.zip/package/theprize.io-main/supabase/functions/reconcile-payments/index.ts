import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";
import { toPrizePid } from "../_shared/userId.ts";

/**
 * Payment Reconciliation Function
 *
 * This function finds and processes any payments that were confirmed by Coinbase
 * but failed to properly credit the user's balance or entries.
 *
 * Run this periodically (e.g., every 15 minutes) via a cron job or manually
 * to ensure no payments are ever lost.
 *
 * What it reconciles:
 * 1. Top-ups: Confirmed payments not credited to user balance
 * 2. Entries: Confirmed payments not credited to joincompetition
 *
 * Endpoint: POST /functions/v1/reconcile-payments
 * Auth: Requires service role key or admin token
 */

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

interface ReconciliationResult {
  success: boolean;
  topUpsReconciled: number;
  entriesReconciled: number;
  totalAmountCredited: number;
  errors: string[];
  transactionsProcessed: string[];
}

Deno.serve(async (req: Request) => {
  const requestId = crypto.randomUUID().slice(0, 8);
  console.log(`[reconcile-payments][${requestId}] Starting reconciliation`);

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const result: ReconciliationResult = {
      success: true,
      topUpsReconciled: 0,
      entriesReconciled: 0,
      totalAmountCredited: 0,
      errors: [],
      transactionsProcessed: [],
    };

    // =====================================================
    // PART 1: RECONCILE TOP-UPS
    // =====================================================
    console.log(`[reconcile-payments][${requestId}] Checking for unconfirmed top-ups...`);

    // Find top-up transactions that:
    // - Have confirmed payment status
    // - No competition_id (= top-up)
    // - Not yet credited (wallet_credited = false/null)
    // - At least 5 minutes old (to avoid racing with webhook)
    const { data: unconfirmedTopUps, error: topUpError } = await supabase
      .from("user_transactions")
      .select("id, user_id, amount, status, payment_status, wallet_credited")
      .is("competition_id", null)
      .in("payment_status", ["confirmed", "completed"])
      .or("wallet_credited.is.null,wallet_credited.eq.false")
      .neq("status", "needs_reconciliation")
      .lt("created_at", new Date(Date.now() - 5 * 60 * 1000).toISOString())
      .order("created_at", { ascending: true })
      .limit(50);

    if (topUpError) {
      console.error(`[reconcile-payments][${requestId}] Error fetching top-ups:`, topUpError);
      result.errors.push(`Top-up fetch error: ${topUpError.message}`);
    } else if (unconfirmedTopUps && unconfirmedTopUps.length > 0) {
      console.log(`[reconcile-payments][${requestId}] Found ${unconfirmedTopUps.length} unconfirmed top-ups`);

      for (const txn of unconfirmedTopUps) {
        try {
          const amount = Number(txn.amount) || 0;
          if (amount <= 0 || !txn.user_id) {
            console.warn(`[reconcile-payments][${requestId}] Skipping invalid top-up ${txn.id}`);
            continue;
          }

          // Use canonical user ID
          const canonicalUserId = toPrizePid(txn.user_id);

          // Attempt to credit the balance
          const { data: creditResult, error: creditError } = await supabase.rpc(
            'credit_sub_account_balance',
            {
              p_canonical_user_id: canonicalUserId,
              p_amount: amount,
              p_currency: 'USD'
            }
          );

          if (creditError) {
            throw new Error(`RPC error: ${creditError.message}`);
          }

          const creditSuccess = creditResult?.[0]?.success ?? false;

          if (creditSuccess) {
            // Mark as credited
            await supabase
              .from("user_transactions")
              .update({
                wallet_credited: true,
                credit_synced: true,
                status: "completed",
                updated_at: new Date().toISOString(),
              })
              .eq("id", txn.id);

            result.topUpsReconciled++;
            result.totalAmountCredited += amount;
            result.transactionsProcessed.push(txn.id);
            console.log(`[reconcile-payments][${requestId}] ✅ Credited top-up ${txn.id}: $${amount} to ${canonicalUserId}`);
          } else {
            throw new Error(creditResult?.[0]?.error_message || 'Credit failed');
          }
        } catch (err) {
          const errorMsg = `Failed to reconcile top-up ${txn.id}: ${(err as Error).message}`;
          console.error(`[reconcile-payments][${requestId}] ${errorMsg}`);
          result.errors.push(errorMsg);

          // Mark for manual review
          await supabase
            .from("user_transactions")
            .update({
              status: "needs_reconciliation",
              updated_at: new Date().toISOString(),
            })
            .eq("id", txn.id);
        }
      }
    } else {
      console.log(`[reconcile-payments][${requestId}] No unconfirmed top-ups found`);
    }

    // =====================================================
    // PART 2: RECONCILE COMPETITION ENTRIES
    // =====================================================
    console.log(`[reconcile-payments][${requestId}] Checking for unconfirmed entries...`);

    // Find entry transactions that:
    // - Have competition_id (= entry purchase)
    // - Have confirmed payment status
    // - Don't have a matching joincompetition entry
    // - At least 5 minutes old
    const { data: unconfirmedEntries, error: entryError } = await supabase
      .from("user_transactions")
      .select("id, user_id, competition_id, ticket_count, amount, tx_id")
      .not("competition_id", "is", null)
      .in("payment_status", ["confirmed", "completed"])
      .neq("status", "needs_reconciliation")
      .lt("created_at", new Date(Date.now() - 5 * 60 * 1000).toISOString())
      .order("created_at", { ascending: true })
      .limit(50);

    if (entryError) {
      console.error(`[reconcile-payments][${requestId}] Error fetching entries:`, entryError);
      result.errors.push(`Entry fetch error: ${entryError.message}`);
    } else if (unconfirmedEntries && unconfirmedEntries.length > 0) {
      console.log(`[reconcile-payments][${requestId}] Checking ${unconfirmedEntries.length} potential unconfirmed entries`);

      for (const txn of unconfirmedEntries) {
        try {
          const canonicalUserId = toPrizePid(txn.user_id);

          // Check if joincompetition entry already exists
          const { data: existingEntry } = await supabase
            .from("joincompetition")
            .select("uid")
            .eq("competitionid", txn.competition_id)
            .eq("transactionhash", txn.tx_id || txn.id)
            .maybeSingle();

          if (existingEntry) {
            // Entry exists - just mark transaction as completed
            await supabase
              .from("user_transactions")
              .update({
                status: "completed",
                updated_at: new Date().toISOString(),
              })
              .eq("id", txn.id);
            continue;
          }

          // Call confirm-pending-tickets to create the entry
          const confirmPayload = {
            userId: canonicalUserId,
            competitionId: txn.competition_id,
            transactionHash: txn.tx_id || txn.id,
            paymentProvider: "coinbase_commerce",
            sessionId: txn.id,
            ticketCount: txn.ticket_count || 1,
          };

          const confirmResponse = await fetch(
            `${supabaseUrl}/functions/v1/confirm-pending-tickets`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${supabaseServiceKey}`,
              },
              body: JSON.stringify(confirmPayload),
            }
          );

          const confirmResult = await confirmResponse.json();

          if (confirmResponse.ok && (confirmResult.success || confirmResult.alreadyConfirmed)) {
            await supabase
              .from("user_transactions")
              .update({
                status: "completed",
                updated_at: new Date().toISOString(),
              })
              .eq("id", txn.id);

            result.entriesReconciled++;
            result.transactionsProcessed.push(txn.id);
            console.log(`[reconcile-payments][${requestId}] ✅ Confirmed entry ${txn.id} for competition ${txn.competition_id}`);
          } else {
            throw new Error(confirmResult.error || 'Confirmation failed');
          }
        } catch (err) {
          const errorMsg = `Failed to reconcile entry ${txn.id}: ${(err as Error).message}`;
          console.error(`[reconcile-payments][${requestId}] ${errorMsg}`);
          result.errors.push(errorMsg);

          // Mark for manual review
          await supabase
            .from("user_transactions")
            .update({
              status: "needs_reconciliation",
              updated_at: new Date().toISOString(),
            })
            .eq("id", txn.id);
        }
      }
    } else {
      console.log(`[reconcile-payments][${requestId}] No unconfirmed entries found`);
    }

    // =====================================================
    // PART 3: CLEAN UP EXPIRED PENDING RECORDS
    // =====================================================
    console.log(`[reconcile-payments][${requestId}] Cleaning up expired pending records...`);

    try {
      // Clean up expired pending_topups
      const { data: expiredTopUps } = await supabase
        .from("pending_topups")
        .update({ status: "expired", updated_at: new Date().toISOString() })
        .eq("status", "pending")
        .lt("expires_at", new Date().toISOString())
        .select("id");

      if (expiredTopUps && expiredTopUps.length > 0) {
        console.log(`[reconcile-payments][${requestId}] Expired ${expiredTopUps.length} pending top-ups`);
      }

      // Clean up expired pending_tickets
      const { data: expiredTickets } = await supabase
        .from("pending_tickets")
        .update({ status: "expired", updated_at: new Date().toISOString() })
        .eq("status", "pending")
        .lt("expires_at", new Date().toISOString())
        .select("id");

      if (expiredTickets && expiredTickets.length > 0) {
        console.log(`[reconcile-payments][${requestId}] Expired ${expiredTickets.length} pending tickets`);
      }
    } catch (cleanupErr) {
      console.warn(`[reconcile-payments][${requestId}] Cleanup error (non-fatal):`, cleanupErr);
    }

    // =====================================================
    // SUMMARY
    // =====================================================
    result.success = result.errors.length === 0;

    console.log(`[reconcile-payments][${requestId}] Reconciliation complete:`, {
      topUpsReconciled: result.topUpsReconciled,
      entriesReconciled: result.entriesReconciled,
      totalAmountCredited: result.totalAmountCredited,
      errors: result.errors.length,
    });

    return new Response(
      JSON.stringify(result),
      {
        status: result.success ? 200 : 207, // 207 = Multi-Status (partial success)
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error(`[reconcile-payments][${requestId}] Unhandled error:`, error);
    return new Response(
      JSON.stringify({
        success: false,
        error: (error as Error).message || "Internal server error",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
