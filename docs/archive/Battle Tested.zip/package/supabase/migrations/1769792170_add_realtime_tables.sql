-- Migration: add_realtime_tables
-- Created at: 1769792170

-- Add missing tables to realtime
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS sub_account_balances;
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS winners;
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS reservations;
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS payments;;