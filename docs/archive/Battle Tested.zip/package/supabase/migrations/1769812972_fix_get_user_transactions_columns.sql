-- Migration: fix_get_user_transactions_columns
-- Created at: 1769812972

CREATE OR REPLACE FUNCTION public.get_user_transactions(user_identifier TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE v_transactions JSONB; v_canonical_user_id TEXT; search_wallet TEXT;
BEGIN
  IF user_identifier LIKE 'prize:pid:0x%' THEN search_wallet := LOWER(SUBSTRING(user_identifier FROM 11));
  ELSIF user_identifier LIKE '0x%' THEN search_wallet := LOWER(user_identifier); END IF;

  SELECT cu.canonical_user_id INTO v_canonical_user_id FROM canonical_users cu
  WHERE cu.canonical_user_id = user_identifier OR cu.uid = user_identifier
  OR (search_wallet IS NOT NULL AND LOWER(cu.wallet_address) = search_wallet) LIMIT 1;

  SELECT jsonb_agg(jsonb_build_object('id', id, 'type', type, 'amount', amount, 'currency', currency, 'status', status,
    'competition_id', competition_id, 'ticket_count', ticket_count,
    'created_at', created_at, 'payment_method', method) ORDER BY created_at DESC) INTO v_transactions
  FROM user_transactions WHERE user_id = user_identifier OR canonical_user_id = v_canonical_user_id OR user_id = v_canonical_user_id LIMIT 100;

  RETURN jsonb_build_object('success', true, 'transactions', COALESCE(v_transactions, '[]'::jsonb));
END;
$$;;