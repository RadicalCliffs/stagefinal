-- Migration: fix_get_user_competition_entries_rpc_v2
-- Created at: 1769814139


DROP FUNCTION IF EXISTS get_user_competition_entries(text);

CREATE OR REPLACE FUNCTION get_user_competition_entries(p_user_identifier text)
RETURNS TABLE (
  id uuid,
  competition_id uuid,
  competition_title text,
  competition_description text,
  competition_image_url text,
  competition_status text,
  competition_end_date timestamptz,
  competition_prize_value numeric,
  competition_is_instant_win boolean,
  ticket_count integer,
  ticket_numbers text,
  amount_paid numeric,
  entry_status text,
  is_winner boolean,
  created_at timestamptz,
  wallet_address text,
  transaction_hash text
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_normalized_id text;
BEGIN
  v_normalized_id := lower(trim(p_user_identifier));
  
  RETURN QUERY
  SELECT 
    ce.id,
    ce.competition_id,
    c.title::text as competition_title,
    c.description::text as competition_description,
    c.image_url::text as competition_image_url,
    c.status::text as competition_status,
    c.end_date as competition_end_date,
    c.prize_value as competition_prize_value,
    COALESCE(c.is_instant_win, false) as competition_is_instant_win,
    ce.tickets_count as ticket_count,
    ce.ticket_numbers_csv::text as ticket_numbers,
    ce.amount_spent as amount_paid,
    'confirmed'::text as entry_status,
    COALESCE(ce.is_winner, false) as is_winner,
    ce.created_at,
    ce.wallet_address::text,
    null::text as transaction_hash
  FROM competition_entries ce
  JOIN competitions c ON c.id = ce.competition_id
  WHERE (
    lower(coalesce(ce.canonical_user_id, '')) = v_normalized_id OR
    lower(coalesce(ce.wallet_address, '')) = v_normalized_id
  )
  ORDER BY ce.latest_purchase_at DESC NULLS LAST;
END;
$$;
;