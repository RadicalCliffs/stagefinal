-- Migration: drop_broken_updated_at_trigger
-- Created at: 1769809421

DROP TRIGGER IF EXISTS update_sub_account_balances_updated_at ON sub_account_balances;;