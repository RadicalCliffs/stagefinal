-- Migration: fix_user_dashboard_entries_add_amount_spent
-- Created at: 1769812193


DROP FUNCTION IF EXISTS get_user_dashboard_entries(text);

CREATE OR REPLACE FUNCTION get_user_dashboard_entries(p_canonical_user_id text)
RETURNS jsonb
LANGUAGE sql STABLE
AS $$
  with u as (
    select cu.id as user_pk,
           cu.canonical_user_id,
           cu.wallet_address,
           cu.base_wallet_address,
           cu.eth_wallet_address,
           coalesce(cu.usdc_balance, 0) as usdc_balance,
           coalesce(cu.bonus_balance, 0) as bonus_balance
    from public.canonical_users cu
    where cu.canonical_user_id = p_canonical_user_id
  ),
  balances as (
    select coalesce(sum(sab.available_balance),0) as available_balance,
           coalesce(sum(sab.pending_balance),0)   as pending_balance
    from public.sub_account_balances sab
    join u on sab.canonical_user_id = u.canonical_user_id
    where sab.currency = 'USD'
  ),
  -- Use competition_entries as the primary source (already aggregated)
  entries_from_ce as (
    select ce.competition_id,
           ce.tickets_count as ticket_count,
           ce.amount_spent,
           ce.created_at as first_purchase_at,
           ce.latest_purchase_at as last_purchase_at,
           c.title,
           c.image_url
    from public.competition_entries ce
    join u on ce.canonical_user_id = u.canonical_user_id
    left join public.competitions c on c.id = ce.competition_id
  ),
  wins as (
    select w.competition_id,
           count(*)::int as win_count,
           jsonb_agg(jsonb_build_object(
             'ticket_number', w.ticket_number,
             'prize', w.prize,
             'prize_value', w.prize_value,
             'won_at', w.won_at
           ) order by w.won_at) as details
    from public.winners w
    join u on (w.wallet_address is not null and lower(w.wallet_address) in (
                 lower(u.wallet_address), lower(u.base_wallet_address), lower(u.eth_wallet_address)
               ))
    group by w.competition_id
  ),
  user_json as (
    select jsonb_build_object(
      'canonical_user_id', u.canonical_user_id,
      'wallet_address', u.wallet_address,
      'base_wallet_address', u.base_wallet_address,
      'eth_wallet_address', u.eth_wallet_address,
      'usdc_balance', u.usdc_balance,
      'bonus_balance', u.bonus_balance
    ) as data
    from u
  ),
  balances_json as (
    select jsonb_build_object(
      'available', coalesce(balances.available_balance,0),
      'pending', coalesce(balances.pending_balance,0)
    ) as data
    from balances
  ),
  entries_json as (
    select coalesce(jsonb_agg(jsonb_build_object(
      'competition_id', e.competition_id,
      'ticket_count', e.ticket_count,
      'amount_spent', coalesce(e.amount_spent, 0),
      'title', e.title,
      'image_url', e.image_url,
      'first_purchase_at', e.first_purchase_at,
      'last_purchase_at', e.last_purchase_at,
      'wins', coalesce(wins.details, '[]'::jsonb)
    ) order by e.last_purchase_at desc) filter (where e.competition_id is not null), '[]'::jsonb) as data
    from entries_from_ce e
    left join wins on wins.competition_id = e.competition_id
  )
  select jsonb_build_object(
    'user', coalesce((select data from user_json), '{}'::jsonb),
    'balances', coalesce((select data from balances_json), '{}'::jsonb),
    'entries', coalesce((select data from entries_json), '[]'::jsonb)
  );
$$;
;