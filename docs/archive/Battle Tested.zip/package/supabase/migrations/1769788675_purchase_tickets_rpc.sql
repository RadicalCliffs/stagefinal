-- Migration: purchase_tickets_rpc
-- Created at: 1769788675

CREATE OR REPLACE FUNCTION purchase_tickets_with_balance(
  p_user_identifier TEXT, p_competition_id TEXT, p_ticket_price NUMERIC, p_ticket_count INTEGER DEFAULT NULL,
  p_ticket_numbers INTEGER[] DEFAULT NULL, p_idempotency_key TEXT DEFAULT NULL
) RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_canonical_user_id TEXT; v_user_uuid TEXT; v_current_balance NUMERIC; v_total_cost NUMERIC; v_new_balance NUMERIC;
  v_final_tickets INTEGER[]; v_competition_total_tickets INTEGER; v_competition_status TEXT; v_entry_id TEXT;
  v_ticket_numbers_str TEXT; v_used_tickets INTEGER[]; v_available_tickets INTEGER[]; v_needed_count INTEGER;
  v_i INTEGER; v_random_index INTEGER; v_ticket_number INTEGER;
BEGIN
  IF p_user_identifier IS NULL OR LENGTH(TRIM(p_user_identifier)) = 0 THEN RETURN jsonb_build_object('success', false, 'error', 'User identifier is required'); END IF;
  IF p_competition_id IS NULL OR LENGTH(TRIM(p_competition_id)) = 0 THEN RETURN jsonb_build_object('success', false, 'error', 'Competition ID is required'); END IF;
  IF p_ticket_price IS NULL OR p_ticket_price <= 0 THEN RETURN jsonb_build_object('success', false, 'error', 'Ticket price must be positive'); END IF;
  IF (p_ticket_count IS NULL AND (p_ticket_numbers IS NULL OR array_length(p_ticket_numbers, 1) IS NULL)) THEN RETURN jsonb_build_object('success', false, 'error', 'Must provide either ticket_count or ticket_numbers'); END IF;

  IF p_user_identifier ~ '^0x[a-fA-F0-9]{40}$' THEN v_canonical_user_id := 'prize:pid:' || LOWER(p_user_identifier);
  ELSIF p_user_identifier LIKE 'prize:pid:%' THEN v_canonical_user_id := LOWER(p_user_identifier);
  ELSE v_canonical_user_id := 'prize:pid:' || LOWER(p_user_identifier); END IF;

  SELECT available_balance, id INTO v_current_balance, v_user_uuid FROM sub_account_balances WHERE canonical_user_id = v_canonical_user_id AND currency = 'USD' FOR UPDATE;
  IF NOT FOUND THEN
    IF p_user_identifier ~ '^0x[a-fA-F0-9]{40}$' THEN
      SELECT sab.available_balance, sab.id INTO v_current_balance, v_user_uuid FROM sub_account_balances sab
      JOIN canonical_users cu ON cu.canonical_user_id = sab.canonical_user_id
      WHERE (LOWER(cu.wallet_address) = LOWER(p_user_identifier) OR LOWER(cu.base_wallet_address) = LOWER(p_user_identifier) OR LOWER(cu.eth_wallet_address) = LOWER(p_user_identifier))
      AND sab.currency = 'USD' LIMIT 1 FOR UPDATE;
    END IF;
    IF NOT FOUND THEN RETURN jsonb_build_object('success', false, 'error', 'User balance not found', 'error_code', 'NO_BALANCE_RECORD'); END IF;
  END IF;

  SELECT total_tickets, status INTO v_competition_total_tickets, v_competition_status FROM competitions WHERE id = p_competition_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('success', false, 'error', 'Competition not found'); END IF;
  IF v_competition_status != 'active' THEN RETURN jsonb_build_object('success', false, 'error', 'Competition is not active', 'competition_status', v_competition_status); END IF;

  IF p_ticket_numbers IS NOT NULL AND array_length(p_ticket_numbers, 1) > 0 THEN v_final_tickets := p_ticket_numbers;
  ELSE
    v_final_tickets := ARRAY[]::INTEGER[];
    SELECT array_agg(DISTINCT ticket_number) INTO v_used_tickets FROM tickets WHERE competition_id = p_competition_id AND ticket_number IS NOT NULL;
    v_available_tickets := ARRAY[]::INTEGER[];
    FOR v_i IN 1..v_competition_total_tickets LOOP
      IF v_used_tickets IS NULL OR NOT (v_i = ANY(v_used_tickets)) THEN v_available_tickets := array_append(v_available_tickets, v_i); END IF;
    END LOOP;
    IF array_length(v_available_tickets, 1) < p_ticket_count THEN
      RETURN jsonb_build_object('success', false, 'error', 'Not enough tickets available', 'available_count', COALESCE(array_length(v_available_tickets, 1), 0), 'requested_count', p_ticket_count);
    END IF;
    v_needed_count := p_ticket_count;
    FOR v_i IN 1..v_needed_count LOOP
      v_random_index := 1 + floor(random() * (array_length(v_available_tickets, 1) - v_i + 1))::INTEGER;
      v_ticket_number := v_available_tickets[v_random_index];
      v_final_tickets := array_append(v_final_tickets, v_ticket_number);
      v_available_tickets[v_random_index] := v_available_tickets[array_length(v_available_tickets, 1) - v_i + 1];
    END LOOP;
  END IF;

  v_total_cost := p_ticket_price * array_length(v_final_tickets, 1);
  IF v_current_balance < v_total_cost THEN RETURN jsonb_build_object('success', false, 'error', 'Insufficient balance', 'error_code', 'INSUFFICIENT_BALANCE', 'required', v_total_cost, 'available', v_current_balance); END IF;
  v_new_balance := v_current_balance - v_total_cost;

  UPDATE sub_account_balances SET available_balance = v_new_balance, updated_at = NOW() WHERE canonical_user_id = v_canonical_user_id AND currency = 'USD';

  INSERT INTO balance_ledger (canonical_user_id, transaction_type, amount, currency, balance_before, balance_after, reference_id, description, created_at)
  VALUES (v_canonical_user_id, 'debit', -v_total_cost, 'USD', v_current_balance, v_new_balance, COALESCE(p_idempotency_key, 'purchase_' || gen_random_uuid()::TEXT), 'Purchase ' || array_length(v_final_tickets, 1) || ' tickets', NOW());

  v_entry_id := gen_random_uuid()::TEXT;
  v_ticket_numbers_str := array_to_string(v_final_tickets, ',');

  BEGIN
    INSERT INTO joincompetition (uid, userid, competitionid, ticketnumbers, ticketcount, amountspent, transactionhash, createdat, updatedat)
    VALUES (v_entry_id, v_canonical_user_id, p_competition_id, v_ticket_numbers_str, array_length(v_final_tickets, 1), v_total_cost, COALESCE(p_idempotency_key, 'balance_' || v_entry_id), NOW(), NOW());
  EXCEPTION WHEN OTHERS THEN NULL; END;

  BEGIN
    INSERT INTO tickets (competition_id, ticket_number, user_id, canonical_user_id, status, created_at)
    SELECT p_competition_id, unnest(v_final_tickets), v_canonical_user_id, v_canonical_user_id, 'sold', NOW();
  EXCEPTION WHEN OTHERS THEN NULL; END;

  RETURN jsonb_build_object('success', true, 'entry_id', v_entry_id, 'ticket_numbers', v_final_tickets, 'ticket_count', array_length(v_final_tickets, 1), 'total_cost', v_total_cost, 'previous_balance', v_current_balance, 'new_balance', v_new_balance, 'competition_id', p_competition_id);
EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('success', false, 'error', 'Internal error: ' || SQLERRM, 'error_code', 'INTERNAL_ERROR');
END;
$$;

REVOKE ALL ON FUNCTION purchase_tickets_with_balance(TEXT, TEXT, NUMERIC, INTEGER, INTEGER[], TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION purchase_tickets_with_balance(TEXT, TEXT, NUMERIC, INTEGER, INTEGER[], TEXT) TO service_role;;