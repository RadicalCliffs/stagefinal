-- Migration: add_canonical_users_uid_unique
-- Created at: 1769803146

-- Add unique constraint on uid column for ON CONFLICT to work
ALTER TABLE canonical_users ADD CONSTRAINT canonical_users_uid_key UNIQUE (uid);;