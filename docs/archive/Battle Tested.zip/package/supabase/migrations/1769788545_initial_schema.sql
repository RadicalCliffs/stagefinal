-- Migration: initial_schema
-- Created at: 1769788545

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Core tables (using IF NOT EXISTS for idempotency)
CREATE TABLE IF NOT EXISTS canonical_users (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  canonical_user_id TEXT UNIQUE,
  uid TEXT UNIQUE NOT NULL DEFAULT gen_random_uuid()::text,
  privy_user_id TEXT UNIQUE,
  email TEXT,
  wallet_address TEXT,
  base_wallet_address TEXT,
  eth_wallet_address TEXT,
  username TEXT,
  avatar_url TEXT,
  usdc_balance NUMERIC(20, 6) DEFAULT 0 NOT NULL,
  bonus_balance NUMERIC(20, 6) DEFAULT 0 NOT NULL,
  has_used_new_user_bonus BOOLEAN DEFAULT false NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  smart_wallet_address TEXT,
  country TEXT,
  first_name TEXT,
  last_name TEXT,
  telegram_handle TEXT,
  is_admin BOOLEAN DEFAULT false NOT NULL,
  auth_provider TEXT,
  wallet_linked TEXT,
  linked_wallets JSONB DEFAULT '[]'::jsonb,
  primary_wallet_address TEXT
);

CREATE TABLE IF NOT EXISTS sub_account_balances (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  canonical_user_id TEXT NOT NULL,
  user_id TEXT,
  privy_user_id TEXT,
  currency TEXT DEFAULT 'USD' NOT NULL,
  available_balance NUMERIC(20, 6) DEFAULT 0 NOT NULL,
  pending_balance NUMERIC(20, 6) DEFAULT 0 NOT NULL,
  bonus_balance NUMERIC(20, 6) DEFAULT 0 NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(canonical_user_id, currency)
);

CREATE TABLE IF NOT EXISTS balance_ledger (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  canonical_user_id TEXT,
  transaction_type TEXT,
  amount NUMERIC(20, 6) NOT NULL,
  currency TEXT DEFAULT 'USD',
  balance_before NUMERIC(20, 6),
  balance_after NUMERIC(20, 6),
  reference_id TEXT,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  source TEXT,
  metadata JSONB,
  transaction_id TEXT
);

CREATE TABLE IF NOT EXISTS tickets_sold (
  competition_id TEXT NOT NULL,
  ticket_number INTEGER NOT NULL,
  purchaser_id TEXT,
  sold_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (competition_id, ticket_number)
);

CREATE TABLE IF NOT EXISTS pending_ticket_items (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  pending_ticket_id TEXT NOT NULL,
  competition_id TEXT NOT NULL,
  ticket_number INTEGER NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE TABLE IF NOT EXISTS competition_entries (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  canonical_user_id TEXT NOT NULL,
  competition_id TEXT NOT NULL,
  wallet_address TEXT,
  tickets_count INTEGER DEFAULT 0 NOT NULL,
  ticket_numbers_csv TEXT,
  amount_spent NUMERIC(20, 6),
  payment_methods TEXT,
  latest_purchase_at TIMESTAMPTZ,
  is_winner BOOLEAN DEFAULT false,
  prize_tiers TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  username TEXT,
  UNIQUE(canonical_user_id, competition_id)
);

CREATE TABLE IF NOT EXISTS _entries_progress (
  competition_id TEXT NOT NULL,
  canonical_user_id TEXT NOT NULL,
  last_ticket_number INTEGER,
  last_processed_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  PRIMARY KEY (competition_id, canonical_user_id)
);

CREATE TABLE IF NOT EXISTS payment_idempotency (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  idempotency_key TEXT UNIQUE NOT NULL,
  user_id TEXT NOT NULL,
  competition_id TEXT,
  amount NUMERIC(20, 6) NOT NULL,
  ticket_count INTEGER NOT NULL,
  result JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '24 hours')
);

CREATE TABLE IF NOT EXISTS _payment_settings (
  key TEXT PRIMARY KEY,
  value_timestamp TIMESTAMPTZ,
  value_json JSONB,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);;