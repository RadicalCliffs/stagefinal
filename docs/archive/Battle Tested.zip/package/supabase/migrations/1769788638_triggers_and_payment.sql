-- Migration: triggers_and_payment
-- Created at: 1769788638

-- Trigger functions
CREATE OR REPLACE FUNCTION update_updated_at_column() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION auto_expire_reservations() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.expires_at IS NOT NULL AND NEW.expires_at < NOW() AND NEW.status = 'pending' THEN NEW.status := 'expired'; END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Timestamp triggers
DROP TRIGGER IF EXISTS update_user_transactions_updated_at ON user_transactions;
CREATE TRIGGER update_user_transactions_updated_at BEFORE UPDATE ON user_transactions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_pending_tickets_updated_at ON pending_tickets;
CREATE TRIGGER update_pending_tickets_updated_at BEFORE UPDATE ON pending_tickets FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_sub_account_balances_updated_at ON sub_account_balances;
CREATE TRIGGER update_sub_account_balances_updated_at BEFORE UPDATE ON sub_account_balances FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_canonical_users_updated_at ON canonical_users;
CREATE TRIGGER update_canonical_users_updated_at BEFORE UPDATE ON canonical_users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_competitions_updated_at ON competitions;
CREATE TRIGGER update_competitions_updated_at BEFORE UPDATE ON competitions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS check_reservation_expiry ON pending_tickets;
CREATE TRIGGER check_reservation_expiry BEFORE INSERT OR UPDATE ON pending_tickets FOR EACH ROW EXECUTE FUNCTION auto_expire_reservations();

-- upsert_canonical_user function
CREATE OR REPLACE FUNCTION upsert_canonical_user(
  p_uid TEXT, p_canonical_user_id TEXT, p_email TEXT DEFAULT NULL, p_username TEXT DEFAULT NULL,
  p_wallet_address TEXT DEFAULT NULL, p_base_wallet_address TEXT DEFAULT NULL, p_eth_wallet_address TEXT DEFAULT NULL, p_privy_user_id TEXT DEFAULT NULL
) RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_user_id TEXT;
BEGIN
  INSERT INTO canonical_users (uid, canonical_user_id, email, username, wallet_address, base_wallet_address, eth_wallet_address, privy_user_id, created_at, updated_at)
  VALUES (p_uid, COALESCE(p_canonical_user_id, p_uid), p_email, p_username, p_wallet_address, p_base_wallet_address, p_eth_wallet_address, p_privy_user_id, NOW(), NOW())
  ON CONFLICT (uid) DO UPDATE SET
    canonical_user_id = COALESCE(EXCLUDED.canonical_user_id, canonical_users.canonical_user_id),
    email = COALESCE(EXCLUDED.email, canonical_users.email),
    username = COALESCE(EXCLUDED.username, canonical_users.username),
    wallet_address = COALESCE(EXCLUDED.wallet_address, canonical_users.wallet_address),
    base_wallet_address = COALESCE(EXCLUDED.base_wallet_address, canonical_users.base_wallet_address),
    eth_wallet_address = COALESCE(EXCLUDED.eth_wallet_address, canonical_users.eth_wallet_address),
    privy_user_id = COALESCE(EXCLUDED.privy_user_id, canonical_users.privy_user_id),
    updated_at = NOW()
  RETURNING id INTO v_user_id;
  RETURN jsonb_build_object('success', true, 'user_id', v_user_id, 'canonical_user_id', p_canonical_user_id);
END;
$$;

GRANT EXECUTE ON FUNCTION upsert_canonical_user(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated, anon, service_role;;