-- Migration: add_realtime_winners
-- Created at: 1769792180

ALTER PUBLICATION supabase_realtime ADD TABLE winners;;