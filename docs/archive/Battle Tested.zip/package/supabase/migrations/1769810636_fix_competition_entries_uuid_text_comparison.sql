-- Migration: fix_competition_entries_uuid_text_comparison
-- Created at: 1769810636

CREATE OR REPLACE FUNCTION public.get_competition_entries_bypass_rls(competition_identifier text)
RETURNS TABLE(
  uid text,
  competitionid text,
  userid text,
  privy_user_id text,
  numberoftickets integer,
  ticketnumbers text,
  amountspent numeric,
  walletaddress text,
  username text,
  chain text,
  transactionhash text,
  purchasedate timestamptz,
  created_at timestamptz
) LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  comp_uuid uuid := NULL;
  comp_uid_text text := NULL;
BEGIN
  BEGIN
    comp_uuid := competition_identifier::uuid;
  EXCEPTION WHEN invalid_text_representation THEN
    comp_uuid := NULL;
  END;

  IF comp_uuid IS NULL THEN
    SELECT c.id, c.uid INTO comp_uuid, comp_uid_text FROM competitions c WHERE c.uid = competition_identifier LIMIT 1;
  ELSE
    SELECT c.uid INTO comp_uid_text FROM competitions c WHERE c.id = comp_uuid LIMIT 1;
  END IF;

  RETURN QUERY
  SELECT
    COALESCE(jc.uid, jc.id::text) as uid,
    jc.competitionid::text as competitionid,
    jc.userid,
    jc.privy_user_id,
    jc.numberoftickets,
    jc.ticketnumbers,
    jc.amountspent,
    jc.wallet_address as walletaddress,
    cu.username as username,
    jc.chain,
    jc.transactionhash,
    jc.purchasedate::timestamptz,
    jc.created_at::timestamptz
  FROM joincompetition jc
  LEFT JOIN canonical_users cu ON (
    cu.canonical_user_id = jc.wallet_address OR
    LOWER(cu.wallet_address) = LOWER(jc.wallet_address) OR
    (jc.canonical_user_id IS NOT NULL AND cu.canonical_user_id = jc.canonical_user_id) OR
    (jc.privy_user_id IS NOT NULL AND cu.privy_user_id = jc.privy_user_id)
  )
  WHERE
    (comp_uuid IS NOT NULL AND jc.competitionid = comp_uuid) OR
    (comp_uid_text IS NOT NULL AND jc.competitionid::text = comp_uid_text)

  UNION ALL

  SELECT
    ('tickets-' || COALESCE(t.privy_user_id,'') || '-' || to_char(MIN(t.created_at), 'YYYY-MM-DD"T"HH24:MI:SS.MS'))::text as uid,
    t.competition_id::text as competitionid,
    t.privy_user_id as userid,
    t.privy_user_id as privy_user_id,
    COUNT(*)::integer as numberoftickets,
    string_agg(t.ticket_number::text, ',' ORDER BY t.ticket_number) as ticketnumbers,
    COALESCE(SUM(t.purchase_price), 0)::numeric as amountspent,
    NULL::text as walletaddress,
    cu.username as username,
    'USDC'::text as chain,
    NULL::text as transactionhash,
    MIN(t.created_at)::timestamptz as purchasedate,
    MIN(t.created_at)::timestamptz as created_at
  FROM tickets t
  LEFT JOIN canonical_users cu ON cu.privy_user_id = t.privy_user_id
  WHERE
    (comp_uuid IS NOT NULL AND t.competition_id = comp_uuid)
    OR (comp_uid_text IS NOT NULL AND t.competition_id::text = comp_uid_text)
  AND NOT EXISTS (
    SELECT 1 FROM joincompetition jc
    WHERE jc.privy_user_id = t.privy_user_id
      AND (
        (comp_uuid IS NOT NULL AND jc.competitionid = comp_uuid)
        OR (comp_uid_text IS NOT NULL AND jc.competitionid::text = comp_uid_text)
      )
      AND jc.ticketnumbers LIKE '%' || t.ticket_number || '%'
  )
  GROUP BY t.competition_id, t.privy_user_id, cu.username

  ORDER BY purchasedate DESC;
END;
$$;;