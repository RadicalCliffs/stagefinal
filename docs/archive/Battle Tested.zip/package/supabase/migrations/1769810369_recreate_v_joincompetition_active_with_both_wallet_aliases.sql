-- Migration: recreate_v_joincompetition_active_with_both_wallet_aliases
-- Created at: 1769810369

DROP VIEW IF EXISTS v_joincompetition_active;
CREATE VIEW v_joincompetition_active AS
SELECT jc.uid,
    jc.userid,
    jc.wallet_address AS walletaddress,
    jc.wallet_address,
    jc.canonical_user_id,
    jc.privy_user_id,
    jc.competitionid,
    jc.numberoftickets,
    jc.ticketnumbers,
    jc.amountspent,
    jc.purchasedate,
    jc.transactionhash,
    jc.chain,
    jc.created_at,
    c.title AS competition_title,
    c.status AS competition_status,
    c.end_date AS competition_draw_date
FROM joincompetition jc
LEFT JOIN competitions c ON jc.competitionid::text = c.id::text
WHERE c.status = ANY (ARRAY['active'::text, 'completed'::text, 'drawing'::text, 'drawn'::text])
  AND jc.numberoftickets > 0 
  AND jc.ticketnumbers IS NOT NULL;;