-- Migration: add_realtime_sub_account
-- Created at: 1769792178

ALTER PUBLICATION supabase_realtime ADD TABLE sub_account_balances;;