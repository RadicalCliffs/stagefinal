-- Migration: fix_upsert_canonical_user_params
-- Created at: 1769794496

-- Fix upsert_canonical_user to accept all parameters the frontend sends
DROP FUNCTION IF EXISTS public.upsert_canonical_user(text, text, text, text, text, text, text, text);
DROP FUNCTION IF EXISTS public.upsert_canonical_user(text, text, text, text, text, text, text, text, text, text, text, boolean);

CREATE OR REPLACE FUNCTION public.upsert_canonical_user(
  p_uid text,
  p_canonical_user_id text,
  p_email text DEFAULT NULL,
  p_username text DEFAULT NULL,
  p_wallet_address text DEFAULT NULL,
  p_base_wallet_address text DEFAULT NULL,
  p_eth_wallet_address text DEFAULT NULL,
  p_privy_user_id text DEFAULT NULL,
  p_first_name text DEFAULT NULL,
  p_last_name text DEFAULT NULL,
  p_telegram_handle text DEFAULT NULL,
  p_wallet_linked boolean DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE v_user_id TEXT;
BEGIN
  INSERT INTO canonical_users (uid, canonical_user_id, email, username, wallet_address, base_wallet_address, eth_wallet_address, privy_user_id, created_at, updated_at)
  VALUES (p_uid, COALESCE(p_canonical_user_id, p_uid), p_email, p_username, p_wallet_address, p_base_wallet_address, p_eth_wallet_address, p_privy_user_id, NOW(), NOW())
  ON CONFLICT (uid) DO UPDATE SET
    canonical_user_id = COALESCE(EXCLUDED.canonical_user_id, canonical_users.canonical_user_id),
    email = COALESCE(EXCLUDED.email, canonical_users.email),
    username = COALESCE(EXCLUDED.username, canonical_users.username),
    wallet_address = COALESCE(EXCLUDED.wallet_address, canonical_users.wallet_address),
    base_wallet_address = COALESCE(EXCLUDED.base_wallet_address, canonical_users.base_wallet_address),
    eth_wallet_address = COALESCE(EXCLUDED.eth_wallet_address, canonical_users.eth_wallet_address),
    privy_user_id = COALESCE(EXCLUDED.privy_user_id, canonical_users.privy_user_id),
    updated_at = NOW()
  RETURNING id INTO v_user_id;
  RETURN jsonb_build_object('success', true, 'user_id', v_user_id, 'canonical_user_id', p_canonical_user_id, 'wallet_linked', p_wallet_linked);
END;
$function$;;