-- Migration: fix_get_unavailable_tickets_v2
-- Created at: 1769792063

CREATE OR REPLACE FUNCTION public.get_unavailable_tickets(p_competition_id text)
RETURNS integer[]
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_competition_uuid UUID;
  v_comp_uid TEXT;
  v_unavailable INTEGER[] := ARRAY[]::INTEGER[];
  v_sold_jc INTEGER[] := ARRAY[]::INTEGER[];
  v_sold_tickets INTEGER[] := ARRAY[]::INTEGER[];
  v_pending INTEGER[] := ARRAY[]::INTEGER[];
BEGIN
  IF p_competition_id IS NULL OR TRIM(p_competition_id) = '' THEN 
    RETURN ARRAY[]::INTEGER[]; 
  END IF;
  
  -- Try to parse as UUID
  BEGIN 
    v_competition_uuid := p_competition_id::UUID;
  EXCEPTION WHEN invalid_text_representation THEN
    SELECT c.id, c.uid INTO v_competition_uuid, v_comp_uid 
    FROM competitions c WHERE c.uid = p_competition_id LIMIT 1;
    IF v_competition_uuid IS NULL THEN 
      RETURN ARRAY[]::INTEGER[]; 
    END IF;
  END;
  
  IF v_comp_uid IS NULL THEN 
    SELECT c.uid INTO v_comp_uid FROM competitions c WHERE c.id = v_competition_uuid; 
  END IF;

  -- Get tickets from joincompetition
  BEGIN 
    SELECT COALESCE(array_agg(DISTINCT ticket_num), ARRAY[]::INTEGER[]) INTO v_sold_jc
    FROM (
      SELECT CAST(TRIM(unnest(string_to_array(ticketnumbers::TEXT, ','))) AS INTEGER) AS ticket_num 
      FROM joincompetition
      WHERE (competitionid = v_competition_uuid::TEXT OR (v_comp_uid IS NOT NULL AND competitionid = v_comp_uid) OR competitionid = p_competition_id)
      AND ticketnumbers IS NOT NULL AND TRIM(ticketnumbers::TEXT) != ''
    ) AS jc_tickets 
    WHERE ticket_num IS NOT NULL;
  EXCEPTION WHEN OTHERS THEN 
    v_sold_jc := ARRAY[]::INTEGER[]; 
  END;

  -- Get tickets from tickets table
  BEGIN 
    SELECT COALESCE(array_agg(DISTINCT t.ticket_number), ARRAY[]::INTEGER[]) INTO v_sold_tickets 
    FROM tickets t
    WHERE t.competition_id = v_competition_uuid;
  EXCEPTION WHEN OTHERS THEN 
    v_sold_tickets := ARRAY[]::INTEGER[]; 
  END;

  -- Get pending tickets
  BEGIN 
    SELECT COALESCE(array_agg(DISTINCT pti.ticket_number), ARRAY[]::INTEGER[]) INTO v_pending 
    FROM pending_ticket_items pti
    INNER JOIN pending_tickets pt ON pti.pending_ticket_id = pt.id
    WHERE pti.competition_id = v_competition_uuid
    AND pt.status IN ('pending', 'confirming') 
    AND pt.expires_at > NOW() 
    AND pti.ticket_number IS NOT NULL;
  EXCEPTION WHEN OTHERS THEN 
    v_pending := ARRAY[]::INTEGER[]; 
  END;

  v_unavailable := COALESCE(v_sold_jc, ARRAY[]::INTEGER[]) || COALESCE(v_sold_tickets, ARRAY[]::INTEGER[]) || COALESCE(v_pending, ARRAY[]::INTEGER[]);
  
  IF array_length(v_unavailable, 1) IS NOT NULL AND array_length(v_unavailable, 1) > 0 THEN
    SELECT COALESCE(array_agg(DISTINCT u ORDER BY u), ARRAY[]::INTEGER[]) INTO v_unavailable 
    FROM unnest(v_unavailable) AS u WHERE u IS NOT NULL;
  ELSE 
    v_unavailable := ARRAY[]::INTEGER[]; 
  END IF;
  
  RETURN v_unavailable;
END;
$function$;;