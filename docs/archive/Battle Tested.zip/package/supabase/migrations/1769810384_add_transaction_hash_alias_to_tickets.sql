-- Migration: add_transaction_hash_alias_to_tickets
-- Created at: 1769810384

ALTER TABLE tickets ADD COLUMN IF NOT EXISTS transaction_hash text GENERATED ALWAYS AS (COALESCE(payment_tx_hash, tx_id)) STORED;;