-- Migration: fix_comprehensive_dashboard_aggregation
-- Created at: 1769813551

CREATE OR REPLACE FUNCTION public.get_comprehensive_user_dashboard_entries(p_user_identifier TEXT)
RETURNS TABLE(
  id UUID, competition_id TEXT, title TEXT, description TEXT, image TEXT, status TEXT,
  entry_type TEXT, is_winner BOOLEAN, ticket_numbers TEXT, total_tickets INTEGER,
  total_amount_spent NUMERIC, purchase_date TIMESTAMPTZ, transaction_hash TEXT,
  is_instant_win BOOLEAN, prize_value NUMERIC, competition_status TEXT, end_date TIMESTAMPTZ
)
LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_canonical_user_id TEXT; search_wallet TEXT;
BEGIN
  IF p_user_identifier LIKE 'prize:pid:0x%' THEN search_wallet := LOWER(SUBSTRING(p_user_identifier FROM 11));
  ELSIF p_user_identifier LIKE '0x%' THEN search_wallet := LOWER(p_user_identifier); END IF;

  SELECT cu.canonical_user_id INTO v_canonical_user_id FROM canonical_users cu
  WHERE cu.canonical_user_id = p_user_identifier OR cu.uid = p_user_identifier
  OR (search_wallet IS NOT NULL AND LOWER(cu.wallet_address) = search_wallet)
  OR (search_wallet IS NOT NULL AND LOWER(cu.base_wallet_address) = search_wallet) LIMIT 1;

  IF v_canonical_user_id IS NULL THEN RETURN; END IF;

  RETURN QUERY
  WITH all_entries AS (
    SELECT jc.competitionid AS comp_id, jc.ticketnumbers AS tnums, jc.numberoftickets AS tcount,
      COALESCE(jc.amountspent, 0) AS tamount, jc.created_at AS pdate, jc.transactionhash AS txhash
    FROM public.joincompetition jc 
    WHERE jc.canonical_user_id = v_canonical_user_id
       OR (search_wallet IS NOT NULL AND LOWER(jc.wallet_address) = search_wallet)
  ),
  aggregated AS (
    SELECT ae.comp_id, 
      string_agg(ae.tnums, ',' ORDER BY ae.pdate) AS all_tickets,
      SUM(ae.tcount) AS total_tix,
      SUM(ae.tamount) AS total_spent,
      MIN(ae.pdate) AS first_purchase,
      MAX(ae.pdate) AS last_purchase,
      (array_agg(ae.txhash ORDER BY ae.pdate DESC))[1] AS latest_txhash
    FROM all_entries ae
    GROUP BY ae.comp_id
  )
  SELECT gen_random_uuid() AS id, a.comp_id::TEXT AS competition_id, c.title, c.description, c.image_url AS image,
    CASE WHEN c.status = 'sold_out' THEN 'sold_out' WHEN c.status = 'active' THEN 'live' ELSE c.status END AS status,
    'aggregated'::TEXT AS entry_type, false AS is_winner, a.all_tickets AS ticket_numbers,
    a.total_tix::INTEGER AS total_tickets, a.total_spent AS total_amount_spent,
    a.last_purchase AS purchase_date, a.latest_txhash AS transaction_hash,
    COALESCE(c.is_instant_win, false) AS is_instant_win, NULL::NUMERIC AS prize_value,
    c.status AS competition_status, c.end_time AS end_date
  FROM aggregated a
  LEFT JOIN competitions c ON a.comp_id = c.id
  ORDER BY a.last_purchase DESC;
END;
$$;;