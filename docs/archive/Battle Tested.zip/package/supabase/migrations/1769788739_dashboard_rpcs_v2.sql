-- Migration: dashboard_rpcs_v2
-- Created at: 1769788739

-- get_comprehensive_user_dashboard_entries
CREATE OR REPLACE FUNCTION get_comprehensive_user_dashboard_entries(p_user_identifier TEXT)
RETURNS TABLE (
  id TEXT, competition_id TEXT, title TEXT, description TEXT, image TEXT, status TEXT, entry_type TEXT,
  is_winner BOOLEAN, ticket_numbers TEXT, total_tickets INTEGER, total_amount_spent NUMERIC,
  purchase_date TIMESTAMPTZ, transaction_hash TEXT, is_instant_win BOOLEAN, prize_value NUMERIC,
  competition_status TEXT, end_date TIMESTAMPTZ
) LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_canonical_user_id TEXT; search_wallet TEXT;
BEGIN
  IF p_user_identifier LIKE 'prize:pid:0x%' THEN search_wallet := LOWER(SUBSTRING(p_user_identifier FROM 11));
  ELSIF p_user_identifier LIKE '0x%' THEN search_wallet := LOWER(p_user_identifier); END IF;

  SELECT cu.canonical_user_id INTO v_canonical_user_id FROM canonical_users cu
  WHERE cu.canonical_user_id = p_user_identifier OR cu.uid = p_user_identifier
  OR (search_wallet IS NOT NULL AND LOWER(cu.wallet_address) = search_wallet)
  OR (search_wallet IS NOT NULL AND LOWER(cu.base_wallet_address) = search_wallet) LIMIT 1;

  IF v_canonical_user_id IS NULL THEN RETURN; END IF;

  RETURN QUERY
  WITH user_entries AS (
    SELECT DISTINCT ce.id, ce.competition_id, c.title, c.description, c.image_url AS image, c.status AS comp_status,
      'competition_entry' AS etype, ce.is_winner, ce.ticket_numbers_csv AS tnums, ce.tickets_count AS ttotal,
      ce.amount_spent AS tamount, ce.latest_purchase_at AS pdate, NULL::TEXT AS txhash,
      c.is_instant_win AS instant, NULL::NUMERIC AS pval, c.end_time AS edate
    FROM competition_entries ce LEFT JOIN competitions c ON ce.competition_id = c.id OR ce.competition_id = c.uid
    WHERE ce.canonical_user_id = v_canonical_user_id
    UNION ALL
    SELECT DISTINCT ut.id, ut.competition_id, c.title, c.description, c.image_url AS image, c.status AS comp_status,
      'transaction' AS etype, false AS is_winner, ut.ticket_numbers AS tnums, ut.ticket_count AS ttotal,
      ut.amount AS tamount, ut.created_at AS pdate, ut.transaction_hash AS txhash, c.is_instant_win AS instant,
      NULL::NUMERIC AS pval, c.end_time AS edate
    FROM user_transactions ut LEFT JOIN competitions c ON ut.competition_id = c.id OR ut.competition_id = c.uid
    WHERE (ut.user_id = v_canonical_user_id OR ut.canonical_user_id = v_canonical_user_id)
    AND ut.payment_status IN ('completed', 'confirmed') AND ut.competition_id IS NOT NULL
  )
  SELECT DISTINCT ON (ue.competition_id) ue.id, ue.competition_id, ue.title, ue.description, ue.image,
    CASE WHEN ue.comp_status = 'sold_out' THEN 'sold_out' WHEN ue.comp_status = 'active' THEN 'live' ELSE ue.comp_status END AS status,
    ue.etype AS entry_type, ue.is_winner, ue.tnums AS ticket_numbers, ue.ttotal AS total_tickets, ue.tamount AS total_amount_spent,
    ue.pdate AS purchase_date, ue.txhash AS transaction_hash, ue.instant AS is_instant_win, ue.pval AS prize_value,
    ue.comp_status AS competition_status, ue.edate AS end_date
  FROM user_entries ue ORDER BY ue.competition_id, ue.pdate DESC;
END;
$$;

-- get_user_transactions
CREATE OR REPLACE FUNCTION get_user_transactions(p_user_identifier TEXT) RETURNS JSONB
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_transactions JSONB; v_canonical_user_id TEXT; search_wallet TEXT;
BEGIN
  IF p_user_identifier LIKE 'prize:pid:0x%' THEN search_wallet := LOWER(SUBSTRING(p_user_identifier FROM 11));
  ELSIF p_user_identifier LIKE '0x%' THEN search_wallet := LOWER(p_user_identifier); END IF;

  SELECT cu.canonical_user_id INTO v_canonical_user_id FROM canonical_users cu
  WHERE cu.canonical_user_id = p_user_identifier OR cu.uid = p_user_identifier
  OR (search_wallet IS NOT NULL AND LOWER(cu.wallet_address) = search_wallet) LIMIT 1;

  SELECT jsonb_agg(jsonb_build_object('id', id, 'type', type, 'amount', amount, 'currency', currency, 'status', status,
    'competition_id', competition_id, 'ticket_count', ticket_count, 'ticket_numbers', ticket_numbers,
    'created_at', created_at, 'payment_method', payment_method) ORDER BY created_at DESC) INTO v_transactions
  FROM user_transactions WHERE user_id = p_user_identifier OR canonical_user_id = v_canonical_user_id OR user_id = v_canonical_user_id LIMIT 100;

  RETURN jsonb_build_object('success', true, 'transactions', COALESCE(v_transactions, '[]'::jsonb));
END;
$$;

-- get_competition_entries
CREATE OR REPLACE FUNCTION get_competition_entries(p_competition_id TEXT, p_limit INTEGER DEFAULT 50, p_offset INTEGER DEFAULT 0) RETURNS JSONB
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_entries JSONB;
BEGIN
  SELECT jsonb_agg(jsonb_build_object('canonical_user_id', ce.canonical_user_id, 'username', COALESCE(ce.username, cu.username, 'Anonymous'),
    'wallet_address', ce.wallet_address, 'tickets_count', ce.tickets_count, 'amount_spent', ce.amount_spent, 'latest_purchase_at', ce.latest_purchase_at)) INTO v_entries
  FROM competition_entries ce LEFT JOIN canonical_users cu ON ce.canonical_user_id = cu.canonical_user_id
  WHERE ce.competition_id = p_competition_id ORDER BY ce.latest_purchase_at DESC LIMIT p_limit OFFSET p_offset;
  RETURN jsonb_build_object('success', true, 'entries', COALESCE(v_entries, '[]'::jsonb));
END;
$$;

GRANT EXECUTE ON FUNCTION get_comprehensive_user_dashboard_entries(TEXT) TO authenticated, anon, service_role;
GRANT EXECUTE ON FUNCTION get_user_transactions(TEXT) TO authenticated, anon, service_role;
GRANT EXECUTE ON FUNCTION get_competition_entries(TEXT, INTEGER, INTEGER) TO authenticated, anon, service_role;;