-- Migration: core_rpc_functions
-- Created at: 1769788576

-- get_user_balance RPC
CREATE OR REPLACE FUNCTION get_user_balance(p_user_identifier TEXT DEFAULT NULL, p_canonical_user_id TEXT DEFAULT NULL)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_balance NUMERIC := 0;
  bonus_balance NUMERIC := 0;
  search_wallet TEXT;
  identifier TEXT;
BEGIN
  identifier := COALESCE(p_user_identifier, p_canonical_user_id);
  
  IF identifier IS NULL OR identifier = '' THEN
    RETURN jsonb_build_object('success', true, 'balance', 0, 'bonus_balance', 0, 'total_balance', 0);
  END IF;

  IF identifier LIKE 'prize:pid:0x%' THEN
    search_wallet := LOWER(SUBSTRING(identifier FROM 11));
  ELSIF identifier LIKE '0x%' AND LENGTH(identifier) = 42 THEN
    search_wallet := LOWER(identifier);
  ELSE
    search_wallet := NULL;
  END IF;

  BEGIN
    SELECT COALESCE(available_balance, 0), COALESCE(sab.bonus_balance, 0)
    INTO user_balance, bonus_balance
    FROM public.sub_account_balances sab
    WHERE currency = 'USD'
      AND (canonical_user_id = identifier OR canonical_user_id = LOWER(identifier)
        OR (search_wallet IS NOT NULL AND canonical_user_id = 'prize:pid:' || search_wallet)
        OR user_id = identifier OR privy_user_id = identifier)
    ORDER BY available_balance DESC NULLS LAST LIMIT 1;

    IF user_balance IS NOT NULL AND user_balance > 0 THEN
      RETURN jsonb_build_object('success', true, 'balance', user_balance, 'bonus_balance', bonus_balance, 'total_balance', user_balance + bonus_balance);
    END IF;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;

  BEGIN
    SELECT COALESCE(usdc_balance, 0), COALESCE(cu.bonus_balance, 0)
    INTO user_balance, bonus_balance
    FROM public.canonical_users cu
    WHERE canonical_user_id = identifier OR canonical_user_id = LOWER(identifier)
      OR (search_wallet IS NOT NULL AND LOWER(wallet_address) = search_wallet)
      OR (search_wallet IS NOT NULL AND LOWER(base_wallet_address) = search_wallet)
      OR LOWER(wallet_address) = LOWER(identifier) OR privy_user_id = identifier
    ORDER BY usdc_balance DESC NULLS LAST LIMIT 1;
  EXCEPTION WHEN OTHERS THEN
    user_balance := 0; bonus_balance := 0;
  END;

  RETURN jsonb_build_object('success', true, 'balance', COALESCE(user_balance, 0), 'bonus_balance', COALESCE(bonus_balance, 0), 'total_balance', COALESCE(user_balance, 0) + COALESCE(bonus_balance, 0));
END;
$$;

-- get_unavailable_tickets RPC
CREATE OR REPLACE FUNCTION get_unavailable_tickets(p_competition_id TEXT)
RETURNS INT4[]
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
DECLARE
  v_competition_uuid UUID;
  v_comp_uid TEXT;
  v_unavailable INTEGER[] := ARRAY[]::INTEGER[];
  v_sold_jc INTEGER[] := ARRAY[]::INTEGER[];
  v_sold_tickets INTEGER[] := ARRAY[]::INTEGER[];
  v_pending INTEGER[] := ARRAY[]::INTEGER[];
BEGIN
  IF p_competition_id IS NULL OR TRIM(p_competition_id) = '' THEN
    RETURN ARRAY[]::INTEGER[];
  END IF;

  BEGIN
    v_competition_uuid := p_competition_id::UUID;
  EXCEPTION WHEN invalid_text_representation THEN
    SELECT c.id::UUID, c.uid INTO v_competition_uuid, v_comp_uid FROM competitions c WHERE c.uid = p_competition_id LIMIT 1;
    IF v_competition_uuid IS NULL THEN RETURN ARRAY[]::INTEGER[]; END IF;
  END;

  IF v_comp_uid IS NULL THEN
    SELECT c.uid INTO v_comp_uid FROM competitions c WHERE c.id = v_competition_uuid::TEXT;
  END IF;

  BEGIN
    SELECT COALESCE(array_agg(DISTINCT ticket_num), ARRAY[]::INTEGER[]) INTO v_sold_jc
    FROM (SELECT CAST(TRIM(unnest(string_to_array(ticketnumbers::TEXT, ','))) AS INTEGER) AS ticket_num
          FROM joincompetition WHERE (competitionid = v_competition_uuid::TEXT OR (v_comp_uid IS NOT NULL AND competitionid = v_comp_uid) OR competitionid = p_competition_id)
          AND ticketnumbers IS NOT NULL AND TRIM(ticketnumbers::TEXT) != '') AS jc_tickets WHERE ticket_num IS NOT NULL;
  EXCEPTION WHEN OTHERS THEN v_sold_jc := ARRAY[]::INTEGER[];
  END;

  BEGIN
    SELECT COALESCE(array_agg(DISTINCT t.ticket_number), ARRAY[]::INTEGER[]) INTO v_sold_tickets
    FROM tickets t WHERE t.competition_id = p_competition_id OR t.competition_id = v_competition_uuid::TEXT OR (v_comp_uid IS NOT NULL AND t.competition_id = v_comp_uid);
  EXCEPTION WHEN OTHERS THEN v_sold_tickets := ARRAY[]::INTEGER[];
  END;

  BEGIN
    SELECT COALESCE(array_agg(DISTINCT pti.ticket_number), ARRAY[]::INTEGER[]) INTO v_pending
    FROM pending_ticket_items pti INNER JOIN pending_tickets pt ON pti.pending_ticket_id = pt.id
    WHERE (pti.competition_id = p_competition_id OR pti.competition_id = v_competition_uuid::TEXT OR (v_comp_uid IS NOT NULL AND pti.competition_id = v_comp_uid))
    AND pt.status IN ('pending', 'confirming') AND pt.expires_at > NOW() AND pti.ticket_number IS NOT NULL;
  EXCEPTION WHEN OTHERS THEN v_pending := ARRAY[]::INTEGER[];
  END;

  v_unavailable := COALESCE(v_sold_jc, ARRAY[]::INTEGER[]) || COALESCE(v_sold_tickets, ARRAY[]::INTEGER[]) || COALESCE(v_pending, ARRAY[]::INTEGER[]);

  IF array_length(v_unavailable, 1) IS NOT NULL AND array_length(v_unavailable, 1) > 0 THEN
    SELECT COALESCE(array_agg(DISTINCT u ORDER BY u), ARRAY[]::INTEGER[]) INTO v_unavailable FROM unnest(v_unavailable) AS u WHERE u IS NOT NULL;
  ELSE
    v_unavailable := ARRAY[]::INTEGER[];
  END IF;

  RETURN v_unavailable;
END;
$$;

GRANT EXECUTE ON FUNCTION get_unavailable_tickets(TEXT) TO authenticated, anon, service_role;
GRANT EXECUTE ON FUNCTION get_user_balance(TEXT, TEXT) TO authenticated, anon, service_role;;