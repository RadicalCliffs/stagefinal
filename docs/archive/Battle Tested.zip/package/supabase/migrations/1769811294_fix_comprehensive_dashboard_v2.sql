-- Migration: fix_comprehensive_dashboard_v2
-- Created at: 1769811294

DROP FUNCTION IF EXISTS get_comprehensive_user_dashboard_entries(TEXT);

CREATE FUNCTION get_comprehensive_user_dashboard_entries(p_user_identifier TEXT)
RETURNS TABLE(
  id UUID, competition_id TEXT, title TEXT, description TEXT, image TEXT, status TEXT,
  entry_type TEXT, is_winner BOOLEAN, ticket_numbers TEXT, total_tickets INT, total_amount_spent NUMERIC,
  purchase_date TIMESTAMPTZ, transaction_hash TEXT, is_instant_win BOOLEAN, prize_value NUMERIC,
  competition_status TEXT, end_date TIMESTAMPTZ
) LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_canonical_user_id TEXT; search_wallet TEXT;
BEGIN
  IF p_user_identifier LIKE 'prize:pid:0x%' THEN search_wallet := LOWER(SUBSTRING(p_user_identifier FROM 11));
  ELSIF p_user_identifier LIKE '0x%' THEN search_wallet := LOWER(p_user_identifier); END IF;

  SELECT cu.canonical_user_id INTO v_canonical_user_id FROM canonical_users cu
  WHERE cu.canonical_user_id = p_user_identifier OR cu.uid = p_user_identifier
  OR (search_wallet IS NOT NULL AND LOWER(cu.wallet_address) = search_wallet)
  OR (search_wallet IS NOT NULL AND LOWER(cu.base_wallet_address) = search_wallet) LIMIT 1;

  IF v_canonical_user_id IS NULL THEN RETURN; END IF;

  RETURN QUERY
  WITH user_entries AS (
    SELECT DISTINCT jc.id, jc.competitionid::TEXT AS competition_id, c.title, c.description, c.image_url AS image, c.status AS comp_status,
      'joincompetition' AS etype, false AS is_winner, jc.ticketnumbers AS tnums, jc.numberoftickets AS ttotal,
      jc.amountspent AS tamount, jc.created_at AS pdate, jc.transactionhash AS txhash,
      c.is_instant_win AS instant, NULL::NUMERIC AS pval, c.end_time AS edate
    FROM public.joincompetition jc 
    LEFT JOIN competitions c ON jc.competitionid = c.id
    WHERE jc.canonical_user_id = v_canonical_user_id
       OR (search_wallet IS NOT NULL AND LOWER(jc.wallet_address) = search_wallet)
    
    UNION ALL
    
    SELECT DISTINCT ut.id, ut.competition_id::TEXT AS competition_id, c.title, c.description, c.image_url AS image, c.status AS comp_status,
      'transaction' AS etype, false AS is_winner, NULL::TEXT AS tnums, ut.ticket_count AS ttotal,
      ut.amount AS tamount, ut.created_at AS pdate, ut.tx_id AS txhash, c.is_instant_win AS instant,
      NULL::NUMERIC AS pval, c.end_time AS edate
    FROM user_transactions ut 
    LEFT JOIN competitions c ON ut.competition_id::TEXT = c.id::TEXT
    WHERE (ut.user_id = v_canonical_user_id OR ut.canonical_user_id = v_canonical_user_id)
    AND ut.payment_status IN ('completed', 'confirmed') AND ut.competition_id IS NOT NULL
  )
  SELECT DISTINCT ON (ue.competition_id) ue.id, ue.competition_id, ue.title, ue.description, ue.image,
    CASE WHEN ue.comp_status = 'sold_out' THEN 'sold_out' WHEN ue.comp_status = 'active' THEN 'live' ELSE ue.comp_status END AS status,
    ue.etype AS entry_type, ue.is_winner, ue.tnums AS ticket_numbers, ue.ttotal AS total_tickets, ue.tamount AS total_amount_spent,
    ue.pdate AS purchase_date, ue.txhash AS transaction_hash, ue.instant AS is_instant_win, ue.pval AS prize_value,
    ue.comp_status AS competition_status, ue.edate AS end_date
  FROM user_entries ue ORDER BY ue.competition_id, ue.pdate DESC;
END;
$$;;